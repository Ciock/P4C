create function task_assignment(username character varying)
  returns TABLE(ident integer, title character varying, descrizione text, creatore character varying, campagna character varying)
language plpgsql
as $$
DECLARE

skills varchar [];

temp_task integer [];

tasks integer [];

j integer;

i varchar(60);

unique_task integer [];

BEGIN

-- Restituisce l'id del task assegnato

skills = array(SELECT got_skills.skill

FROM p4c.got_skills

WHERE worker = username);

-- Skill del lavoratore

FOREACH i IN ARRAY skills LOOP

temp_task = array(SELECT task

FROM p4c.contains_keyword

WHERE i SIMILAR TO '%' || keyword || '%');

FOREACH j IN array temp_task LOOP

unique_task = array [j];

IF (tasks @> unique_task)

THEN

ELSE

tasks = tasks || unique_task;

END IF;

END LOOP;

END LOOP;

-- Restituisco i task che gli propongo

RETURN QUERY
SELECT id, titolo, description, task.requester, task.campaign FROM p4c.task WHERE task.id = any(tasks);

END;

$$;

alter function task_assignment(varchar)
  owner to postgres;

