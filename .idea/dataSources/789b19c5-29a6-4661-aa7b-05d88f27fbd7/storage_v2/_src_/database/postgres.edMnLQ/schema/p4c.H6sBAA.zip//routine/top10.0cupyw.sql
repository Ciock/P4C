create function top10(campagna character varying, requester_campaign character varying)
  returns TABLE(lavoratore character varying, punteggio integer)
language plpgsql
as $$
DECLARE
  keywords     varchar [];
  users        varchar [];
  temp_users   varchar [];
  j            varchar(60);
  u            varchar(20);
  index        integer;
  unique_users varchar [];

BEGIN
  index = 1;
  FOR j in (SELECT DISTINCT keyword
            FROM p4c.contains_keyword
            JOIN p4c.task ON contains_keyword.task = task.id
             JOIN p4c.campaign ON task.campaign = campagna and task.requester = requester_campaign) LOOP
    keywords [index] = j;
    index = index + 1;
  end loop;

  FOREACH j IN ARRAY keywords LOOP
    temp_users = array(SELECT worker
                       FROM p4c.got_skills
                       WHERE skill SIMILAR TO '%' || j || '%'
                       AND worker IN (SELECT MR.worker FROM p4c.made_response AS MR
                                      JOIN p4c.worker AS WO ON MR.worker = WO.username
                                      JOIN p4c.response AS R ON MR.response = R.id
                                      JOIN p4c.task AS T ON R.task = T.id
                                      WHERE T.campaign = $1 AND T.requester = $2));
    FOREACH u IN ARRAY temp_users LOOP
      unique_users = array [u];
      IF (users @> unique_users)
      THEN
      ELSE
        users = users || unique_users;
      END IF;
    end loop;
  END LOOP;

  -- Ora ordinamento e selezione dei primi 10
  RETURN QUERY
  SELECT
         username,
         score
  FROM p4c.worker
  WHERE username = any (users) -- tra un qualsiasi user in users
  ORDER BY score DESC
  LIMIT 10;

END;
$$;

alter function top10(varchar, varchar)
  owner to postgres;

