create function report(campagna character varying, requester_campaign character varying)
  returns TABLE(task_id integer, task character varying, task_result boolean)
language plpgsql
as $$
DECLARE

BEGIN

  RETURN QUERY

  SELECT

    id,

    titolo,

    result

  FROM p4c.campaign AS C

    JOIN p4c.task AS T ON T.campaign = C.title

  WHERE C.title = campagna AND C.requester = requester_campaign;

END;

$$;

