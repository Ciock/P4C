CREATE FUNCTION report(campagna character varying, requester_campaign character varying)
  RETURNS TABLE(task_id integer, task character varying, task_result boolean)
LANGUAGE plpgsql
AS $$
DECLARE

BEGIN

  RETURN QUERY

  SELECT

    id,

    titolo,

    result

  FROM p4c.campaign AS C

    JOIN p4c.task AS T ON T.campaign = C.title

  WHERE C.title = campagna AND C.requester = requester_campaign;

END;

$$;

