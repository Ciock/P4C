create function final_report(campagna character varying, requester_campaign character varying)
  returns TABLE(total_tasks integer, running_task integer, validation_rate double precision)
language plpgsql
as $$
BEGIN
  RETURN QUERY
  SELECT
    count(*)                                                                         as total,
    COUNT(*) - COUNT(T.result)                                                       as running,
    (cast(COUNT(*) as double precision) -
     cast(COUNT(T.result) as double precision) / cast(count(*) as double precision)) as rate
  FROM p4c.campaign AS C
    JOIN p4c.task AS T ON T.campaign = C.title
  WHERE C.title = campagna AND C.requester = requester_campaign
  GROUP BY C.title;

END;

$$;

alter function final_report(varchar, varchar)
  owner to postgres;

