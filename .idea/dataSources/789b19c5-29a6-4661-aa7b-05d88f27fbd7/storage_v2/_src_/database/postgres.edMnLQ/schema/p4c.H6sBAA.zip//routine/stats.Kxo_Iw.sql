create function stats(this_worker character varying)
  returns TABLE(lavoratore character varying, punteggio integer, posizione integer, task_eseguiti integer[], task_validi integer[])
language plpgsql
as $$
DECLARE
  index      integer;
  workers    varchar [];
  valid_task varchar [];
  j          varchar(20);
BEGIN

  lavoratore = this_worker;

  select score
  into punteggio
  from p4c.worker
  where username = this_worker;

  workers = array(SELECT username
                  FROM p4c.worker
                  ORDER BY score DESC);

  posizione = 1;
  FOREACH j IN ARRAY workers LOOP
    IF this_worker = j
    THEN
      EXIT; -- l'index sarà la posizione in classifica
    ELSE
      posizione = posizione + 1;
    END IF;
  END LOOP;

  task_eseguiti = array(SELECT DISTINCT R.task
                FROM p4c.response AS R
                  JOIN p4c.made_response AS M
                    ON R.id = M.response
                WHERE M.worker = this_worker);

  task_validi = array(SELECT id
                     FROM p4c.task
                     WHERE task.result IS NOT NULL AND id = ANY (task_eseguiti));

  RETURN NEXT;

END;
$$;

alter function stats(varchar)
  owner to postgres;

