create function check_result()
  returns trigger
language plpgsql
as $$
DECLARE
  w_counter              int;
  this_n_worker          int;
  count_max_response     int;
  this_majority_treshold int;
  my_treshold            float;
  this_task              int;
  correct_response       int;

BEGIN
  select
    task.id,
    task.n_worker,
    task.majority_threshold
  into this_task, this_n_worker, this_majority_treshold
  from p4c.task
    join p4c.response on task.id = response.task
    join p4c.made_response on response.id = made_response.response
  where new.response = made_response.response
  group by task.id;

  select count(*)
  into w_counter
  from p4c.task
    join p4c.response on task.id = response.task
    join p4c.made_response on response.id = made_response.response
  where this_task = task.id;

  if (w_counter >= this_n_worker)
  then
    select
      max(c2.counter),
      c2.responses
    into count_max_response, correct_response
    from (
           select
             count(worker)          as counter,
             made_response.response as responses
           from p4c.task
             join p4c.response on task.id = response.task
             join p4c.made_response on response.id = made_response.response
           group by made_response.response) as c2
    group by c2.responses;



    my_treshold = count_max_response :: float / w_counter;

    if (my_treshold > this_majority_treshold)
    then
      update p4c.task
      set result = true, response = correct_response
      where id = this_task;
    end if;

  end if;
  RETURN NULL;

END;
$$;

alter function check_result()
  owner to postgres;

