create function result_update()
  returns trigger
language plpgsql
as $$
DECLARE
	w_counter              int;
  this_n_worker          int;
  count_max_response     int;
  this_majority_treshold int;
  my_treshold            float;
  this_task              int;
  correct_response       int;
  date_ultima            date;
  campagna               p4c.campaign.title%TYPE;
BEGIN

	SELECT p4c.task.id INTO this_task
	from p4c.task
    join p4c.response on task.id = response.task
    join p4c.made_response on response.id = made_response.response
  where new.response = made_response.response
  group by task.id;

  SELECT C.title INTO campagna FROM p4c.campaign AS C
  JOIN p4c.task AS T ON T.campaign = C.title
  WHERE NOT (now()::date BETWEEN C.registration_deadline_date AND C.opening_date);

  UPDATE p4c.task SET result = false WHERE task.campaign = C.title;

  select count(*)
  into w_counter
  from p4c.task
    join p4c.response on task.id = response.task
    join p4c.made_response on response.id = made_response.response
  where this_task = task.id;

  if (w_counter >= this_n_worker)
  then
    select
      max(c2.counter),
      c2.responses
    into count_max_response, correct_response
    from (
           select
             count(worker)          as counter,
             made_response.response as responses
           from p4c.task
             join p4c.response on task.id = response.task
             join p4c.made_response on response.id = made_response.response
           group by made_response.response) as c2
    group by c2.responses;

    my_treshold = count_max_response :: float / w_counter;

    if (my_treshold > this_majority_treshold)
    then
      update p4c.task
      set result = true, response = correct_response
      where id = this_task;
    end if;

  end if;

  SELECT C.registration_deadline_date INTO date_ultima FROM p4c.campaign AS C
  JOIN p4c.task AS T ON C.title = T.campaign WHERE this_task = T.id AND T.result IS NULL;

  IF (SELECT now()::date >= date_ultima) THEN
    UPDATE p4c.task set result = false WHERE id = this_task;
  RETURN NULL;
  END IF;

  RETURN NULL;

END;
$$;

alter function result_update()
  owner to postgres;

