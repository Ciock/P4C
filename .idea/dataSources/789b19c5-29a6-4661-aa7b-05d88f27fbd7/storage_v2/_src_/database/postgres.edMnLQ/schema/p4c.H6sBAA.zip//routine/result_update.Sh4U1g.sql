create function result_update()
  returns trigger
language plpgsql
as $$
DECLARE
  w_counter INT;
  this_n_worker INT;
  count_max_response INT;
  this_majority_treshold INT;
  my_treshold FLOAT;
  this_task INT;
  correct_response INT;
BEGIN

  SELECT p4c.task.id, p4c.task.n_worker, p4c.task.majority_threshold
      INTO this_task, this_n_worker, this_majority_treshold
  FROM p4c.task
         JOIN p4c.response ON p4c.task.id = p4c.response.task
         JOIN p4c.made_response ON p4c.response.id = p4c.made_response.response
  WHERE new.response = p4c.made_response.response
  GROUP BY task.id;

  SELECT count(*)
      INTO w_counter
  FROM p4c.task
         JOIN p4c.response ON p4c.task.id = p4c.response.task
         JOIN p4c.made_response ON p4c.response.id = p4c.made_response.response
  WHERE this_task = p4c.task.id;

  IF (w_counter >= this_n_worker)
  THEN
    WITH k (counter, responses) AS (
        SELECT count(p4c.made_response.worker), p4c.made_response.response
        FROM p4c.task
               JOIN p4c.response ON p4c.task.id = p4c.response.task
               JOIN p4c.made_response ON p4c.response.id = p4c.made_response.response
        WHERE p4c.task.id = this_task
        GROUP BY p4c.made_response.response)

    SELECT max(k.counter), k.responses INTO count_max_response, correct_response
    FROM k
    GROUP BY k.responses;

    my_treshold = ((count_max_response*1.0) / w_counter);

    IF (my_treshold >= this_majority_treshold)
    THEN
      UPDATE p4c.task
      SET result = TRUE, response = correct_response
      WHERE id = this_task;
    ELSE
      UPDATE p4c.task
      SET result = FALSE
      WHERE id = this_task;
    END IF;
  END IF;

  RETURN NULL;

END;
$$;

alter function result_update()
  owner to postgres;

