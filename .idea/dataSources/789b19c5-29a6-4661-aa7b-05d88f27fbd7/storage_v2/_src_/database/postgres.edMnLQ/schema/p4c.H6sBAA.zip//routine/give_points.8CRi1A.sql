CREATE FUNCTION give_points()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE

  workers         varchar [];

  correct_workers varchar [];

  i               varchar(20);

  task_keywords   varchar [];

  j               varchar(60);

BEGIN

  workers = array(

      select worker

      from (

             -- Tutti i lavoratori al task

             select worker

             from p4c.made_response

             where made_response.response in (

               -- Risposte relative al task

               select response.id

               from p4c.response

                 join p4c.task on response.task = task.id

               where new.id = task.id)) as w1

      except (

        -- lavoratori che hanno risposto correttemente

        select worker

        from p4c.made_response

        where made_response.response = new.response)

  );

  correct_workers = array(

      select worker

      from p4c.made_response

      where made_response.response = new.response);

  task_keywords = array(

      select keyword

      from p4c.contains_keyword

      where contains_keyword.task = new.id);

  -- decremento score di lavoratori che hanno risposto sbagliato

  FOREACH i IN array workers LOOP

    UPDATE p4c.worker

    SET score = score - 1

    WHERE username = i;

    FOREACH j IN array task_keywords LOOP

      UPDATE p4c.got_skills

      SET skill_score = skill_score - 1

      WHERE got_skills.worker = i AND got_skills.skill similar to '%' || j || '%';

    END LOOP;

  END LOOP;

  IF (new.result IS TRUE)

  THEN

    -- incremento score di lavoratori che hanno risposto correttemente

    FOREACH i IN array correct_workers LOOP

      UPDATE p4c.worker

      SET score = score + 1

      WHERE username = i;

      FOREACH j IN array task_keywords LOOP

        UPDATE p4c.got_skills

        SET skill_score = skill_score + 1

        WHERE got_skills.worker = i AND skill like '%' || j || '%';

      END LOOP;

    END LOOP;

  ELSE

    -- decremento score di tutti lavoratori

    FOREACH i IN array correct_workers LOOP

      UPDATE p4c.worker

      SET score = score - 1

      WHERE username = i;

      FOREACH j IN array task_keywords LOOP

        UPDATE p4c.got_skills

        SET skill_score = skill_score - 1

        WHERE got_skills.worker = i AND skill like '%' || j || '%';

      END LOOP;

    END LOOP;

  END IF;

  RETURN NULL;

END;

$$;

