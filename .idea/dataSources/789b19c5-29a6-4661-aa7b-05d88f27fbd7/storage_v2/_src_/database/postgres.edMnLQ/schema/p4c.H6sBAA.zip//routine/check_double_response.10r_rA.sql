create function check_double_response()
  returns trigger
language plpgsql
as $$
DECLARE

  counter   int;

  this_task int;

BEGIN

  select response.task

  into this_task

  from p4c.response

    join p4c.made_response on response.id = made_response.response

  where new.response = made_response.response;

  select count(responses) into counter

  from (

         select response

         from p4c.made_response

         where new.worker = worker and response in(

           select id

           from p4c.response

           where response.task = this_task)) as responses;

  if (counter <> 0)

  then

    raise exception 'Already answered this task';

    return null;

  end if;

  RETURN new;

END;

$$;

